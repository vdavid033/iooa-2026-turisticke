-- Pokrenuti samo ako tablica Komentari još nema stupac za korisnika.
-- Bez ovog stupca aplikacija ne može trajno povezati komentar s korisničkim imenom.

ALTER TABLE Komentari
  ADD COLUMN VK_ID_korisnika INT NULL;

CREATE INDEX idx_komentari_korisnik
  ON Komentari (VK_ID_korisnika);
